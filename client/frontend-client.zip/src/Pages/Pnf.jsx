import React from 'react'

const Pnf = () => {
  return (
    <div>
      <h1 className='display-5 text-center m-20 '>Requested path is not found</h1>
      </div>
  )
}

export default Pnf