import React from 'react'

const Home = () => {
  return (
    <div className='text-success text-center display-4'></div>
  )
}

export default Home